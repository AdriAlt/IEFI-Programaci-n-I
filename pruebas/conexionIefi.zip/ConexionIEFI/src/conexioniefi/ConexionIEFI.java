/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package conexioniefi;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author chino
 */
public class ConexionIEFI {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws SQLException {
        Conexion conect = new Conexion();
//        try {
//            cn = conect.conectar();
//            st=cn.createStatement();
//            rs=st.executeQuery("select * from dpto_punto_com.localidad");
//            
//            while (rs.next()) {                
//                System.out.println(rs.getInt("id_localidad")+" " +rs.getString("nombre_loc")+ " " +rs.getString("provincia"));
//            }
//        } catch (SQLException e) {
        conect.listar();
//        }
    }
    
}
