/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package conexioniefi;

import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;


/**
 *
 * @author chino
 */
public class Conexion {
    
        public static final String USER = "root";
        public static final String CLAVE = "abcd1234";
        public static final String URL = "jdbc:mysql://localhost:3306/iefi";
    
    public Connection conectar() throws SQLException{
        
        Connection conex = null;
        try {
                Class.forName("com.mysql.cj.jdbc.Driver");
                System.out.println("Driver cargado");
            } catch (Exception e) {
                System.out.println("Error en carga de driver" + e.getMessage());  
            }
        
        try {
            conex = DriverManager.getConnection(URL,USER,CLAVE);
            System.out.println("Conexion exitosa");
        } catch(Exception e){
            System.out.println("No se pudo conectar" + e.getMessage());  
        }
            return conex;
            
    }
    
    public void listar() throws SQLException{
        
        try {
        Connection listar  = conectar();
        Statement listado = listar.createStatement();
        ResultSet result = listado.executeQuery("SELECT * FROM iefi.Alumnos");
        while (result.next()) {                
                System.out.println(result.getInt("id_alumno")+" " +result.getString("nombre")+ " " +result.getString("apellido")+ " "+result.getInt("dni"));
            }
        } catch (Exception e) {
            System.out.println("No se pudo listar" + e.getMessage());
        }
        
        
    }
    
    public void insertar(){
        
        try {
            Connection listar  = conectar();
            Statement listado = listar.createStatement();
            ResultSet result = listado.executeQuery("SELECT * FROM dpto_punto_com.localidad");
            while (result.next()) {                
                System.out.println(result.getInt("id_localidad")+" " +result.getString("nombre_loc")+ " " +result.getString("provincia"));
            }
        } catch (Exception e) {
            System.out.println("No se pudo insertar" + e.getMessage());
        }
    }
            
}
    

