
package conexioniefi;

import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;


public class Conexion {
    
    //Atributos de la clase para conexion a BD
    private  String usuario;
    private  String clave;
    private  String url;
        
    //Metodo constructor
    
    public Conexion(String url,String usr, String clave) {
        
        this.url = url;
        this.usuario = usr;
        this.clave = clave;
                
    }    
    
    //Metodo para conectar a la BD
    
    private Connection conectar() throws SQLException{
        
        Connection conex = null;
        
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            //System.out.println("Driver cargado");
            } catch (Exception e) {
                System.out.println("Error en carga de driver" + e.getMessage());  
            }
        
        try {
            conex = DriverManager.getConnection(url,usuario,clave);
            //System.out.println("Conexion exitosa");
        } catch(Exception e){
            System.out.println("No se pudo conectar" + e.getMessage());  
        }
            return conex;
            
    }
    
    public void listar() throws SQLException{
        
        try {
        Connection listar  = conectar();
        Statement listado = listar.createStatement();
        ResultSet result = listado.executeQuery("SELECT * FROM iefi.Alumnos");
        while (result.next()) {                
                System.out.println(result.getInt("id_alumno")+" " +result.getString("nombre")+ " " +result.getString("apellido")+ " "+result.getInt("dni"));
            }
        } catch (Exception e) {
            System.out.println("No se pudo listar" + e.getMessage());
        }
        
        
    }
    
    public void insertar(){
        
        try {
            Connection listar  = conectar();
            Statement listado = listar.createStatement();
            ResultSet result = listado.executeQuery("SELECT * FROM dpto_punto_com.localidad");
            while (result.next()) {                
                System.out.println(result.getInt("id_localidad")+" " +result.getString("nombre_loc")+ " " +result.getString("provincia"));
            }
        } catch (Exception e) {
            System.out.println("No se pudo insertar" + e.getMessage());
        }
    }
    
    
    
    public void actualizar(){
        
        try {
            Connection listar  = conectar();
            Statement listado = listar.createStatement();
            ResultSet result = listado.executeQuery("SELECT * FROM dpto_punto_com.localidad");
            while (result.next()) {                
                System.out.println(result.getInt("id_localidad")+" " +result.getString("nombre_loc")+ " " +result.getString("provincia"));
            }
        } catch (Exception e) {
            System.out.println("No se pudo insertar" + e.getMessage());
        }
    }
        
        
    public void borrar(){
        
        try {
            Connection listar  = conectar();
            Statement listado = listar.createStatement();
            ResultSet result = listado.executeQuery("SELECT * FROM dpto_punto_com.localidad");
            while (result.next()) {                
                System.out.println(result.getInt("id_localidad")+" " +result.getString("nombre_loc")+ " " +result.getString("provincia"));
            }
        } catch (Exception e) {
            System.out.println("No se pudo insertar" + e.getMessage());
        }
    }
            
}
    

